from __future__ import annotations

import argparse
import json
import stat
from pathlib import Path

from . import data_profile as native


def _profile_input_file(value: str, record_key: str | None) -> dict:
    if not value.strip():
        raise native.DataProfileError("input file must be a non-empty path")
    candidate = Path(value).absolute()
    if native._has_symlink_component(candidate):
        raise native.DataProfileError("symlink data paths are rejected")
    try:
        if not stat.S_ISREG(candidate.lstat().st_mode):
            raise native.DataProfileError("input file must name a regular file")
        root = candidate.parent.resolve(strict=True)
    except OSError as exc:
        raise native.DataProfileError("input file must name an existing regular file") from exc
    return native.profile_data(
        str(candidate), record_key=record_key, repo_root=root,
        allowed_roots=(root / candidate.name,),
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Profile one bounded local data source")
    paths = parser.add_mutually_exclusive_group()
    paths.add_argument("--path", default="data/attachments/input.csv",
                       help="Path inside the current directory's attachment/download/extraction areas")
    paths.add_argument("--input-file",
                       help="Explicit standalone input file; output path is relative to its parent")
    parser.add_argument("--record-key")
    args = parser.parse_args()
    try:
        if args.input_file is not None:
            result = _profile_input_file(args.input_file, args.record_key)
        else:
            result = native.profile_data(
                args.path,
                record_key=args.record_key,
                repo_root=Path.cwd(),
            )
    except native.DataProfileError as exc:
        print(json.dumps({"error": str(exc), "status": "error"}, sort_keys=True))
        return 1
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
